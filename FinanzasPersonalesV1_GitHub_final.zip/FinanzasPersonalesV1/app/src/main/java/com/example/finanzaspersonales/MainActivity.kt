package com.example.finanzaspersonales

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import java.util.UUID

data class Movement(
    val id: String = UUID.randomUUID().toString(),
    val type: String,
    val amount: Double,
    val category: String,
    val note: String = ""
)

data class SavingGoal(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val target: Double,
    val saved: Double = 0.0
)

class FinanceViewModel : ViewModel() {
    var movements by mutableStateOf(listOf<Movement>())
        private set
    var goals by mutableStateOf(listOf(SavingGoal(name = "Meta de ahorro", target = 7000.0)))
        private set

    val income get() = movements.filter { it.type == "income" }.sumOf { it.amount }
    val expenses get() = movements.filter { it.type == "expense" }.sumOf { it.amount }
    val savings get() = goals.sumOf { it.saved }
    val balance get() = income - expenses

    fun addMovement(type: String, amount: Double, category: String, note: String) {
        if (amount > 0) movements = movements + Movement(type = type, amount = amount, category = category, note = note)
    }
    fun deleteMovement(id: String) { movements = movements.filterNot { it.id == id } }
    fun addGoal(name: String, target: Double) {
        if (name.isNotBlank() && target > 0) goals = goals + SavingGoal(name = name, target = target)
    }
    fun addToGoal(id: String, amount: Double) {
        if (amount <= 0) return
        goals = goals.map { if (it.id == id) it.copy(saved = (it.saved + amount).coerceAtMost(it.target)) else it }
    }
}

fun money(v: Double) = "$" + "%.2f".format(v)

@Composable
fun App(vm: FinanceViewModel) {
    val nav = rememberNavController()
    Scaffold(
        bottomBar = {
            NavigationBar {
                listOf(
                    "inicio" to Icons.Default.Home,
                    "movimientos" to Icons.Default.SwapHoriz,
                    "ahorros" to Icons.Default.Savings,
                    "estadisticas" to Icons.Default.BarChart,
                    "deudas" to Icons.Default.CreditCard,
                    "salario" to Icons.Default.Payments
                ).forEach { (route, icon) ->
                    NavigationBarItem(
                        selected = nav.currentDestination?.route == route,
                        onClick = { nav.navigate(route) { launchSingleTop = true } },
                        icon = { Icon(icon, null) },
                        label = { Text(route.replaceFirstChar { it.uppercase() }) }
                    )
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = "inicio", modifier = Modifier.padding(pad)) {
            composable("inicio") { HomeScreen(vm) }
            composable("movimientos") { MovementsScreen(vm) }
            composable("ahorros") { SavingsScreen(vm) }
            composable("estadisticas") { StatsScreen(vm) }
            composable("deudas") { DebtScreen() }
            composable("salario") { SalaryScreen() }
        }
    }
}

@Composable
fun HomeScreen(vm: FinanceViewModel) {
    var show by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Mis Finanzas", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("Saldo disponible")
                    Text(money(vm.balance), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                }
            }
        }
        item { SummaryCard("Ingresos", money(vm.income), Icons.Default.TrendingUp) }
        item { SummaryCard("Gastos", money(vm.expenses), Icons.Default.TrendingDown) }
        item { SummaryCard("Ahorros", money(vm.savings), Icons.Default.Savings) }
        item {
            Button(onClick = { show = true }, modifier = Modifier.fillMaxWidth()) { Text("Registrar movimiento") }
        }
    }
    if (show) MovementDialog(vm) { show = false }
}

@Composable
fun SummaryCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null)
            Spacer(Modifier.width(14.dp))
            Column { Text(title); Text(value, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge) }
        }
    }
}

@Composable
fun MovementsScreen(vm: FinanceViewModel) {
    var show by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Movimientos", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            FloatingActionButton(onClick = { show = true }) { Icon(Icons.Default.Add, null) }
        }
        Spacer(Modifier.height(16.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.movements.reversed(), key = { it.id }) { m ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(m.category, fontWeight = FontWeight.Bold)
                            if (m.note.isNotBlank()) Text(m.note, style = MaterialTheme.typography.bodySmall)
                            Text(if (m.type == "income") "+${money(m.amount)}" else "-${money(m.amount)}")
                        }
                        IconButton(onClick = { vm.deleteMovement(m.id) }) { Icon(Icons.Default.Delete, null) }
                    }
                }
            }
        }
    }
    if (show) MovementDialog(vm) { show = false }
}

@Composable
fun MovementDialog(vm: FinanceViewModel, close: () -> Unit) {
    var type by remember { mutableStateOf("expense") }
    var amount by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("General") }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = close,
        title = { Text("Nuevo movimiento") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(type == "income", { type = "income" }, label = { Text("Ingreso") })
                    FilterChip(type == "expense", { type = "expense" }, label = { Text("Gasto") })
                }
                OutlinedTextField(amount, { amount = it }, label = { Text("Monto") })
                OutlinedTextField(category, { category = it }, label = { Text("Categoría") })
                OutlinedTextField(note, { note = it }, label = { Text("Descripción") })
            }
        },
        confirmButton = {
            TextButton(onClick = { vm.addMovement(type, amount.toDoubleOrNull() ?: 0.0, category, note); close() }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = close) { Text("Cancelar") } }
    )
}

@Composable
fun SavingsScreen(vm: FinanceViewModel) {
    var show by remember { mutableStateOf(false) }
    var goalId by remember { mutableStateOf<String?>(null) }
    var amount by remember { mutableStateOf("") }
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Mis ahorros", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Button({ show = true }) { Text("Nueva meta") }
            }
        }
        items(vm.goals, key = { it.id }) { g ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(g.name, fontWeight = FontWeight.Bold)
                    Text("${money(g.saved)} de ${money(g.target)}")
                    LinearProgressIndicator(
                        progress = { (g.saved / g.target).toFloat().coerceIn(0f,1f) },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button({ goalId = g.id; amount = "" }) { Text("Añadir ahorro") }
                }
            }
        }
    }
    if (show) {
        var name by remember { mutableStateOf("") }
        var target by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { show = false }, title = { Text("Nueva meta") },
            text = { Column {
                OutlinedTextField(name, { name = it }, label = { Text("Nombre") })
                OutlinedTextField(target, { target = it }, label = { Text("Objetivo") })
            }},
            confirmButton = { TextButton({ vm.addGoal(name, target.toDoubleOrNull() ?: 0.0); show = false }) { Text("Crear") } },
            dismissButton = { TextButton({ show = false }) { Text("Cancelar") } })
    }
    if (goalId != null) {
        AlertDialog(onDismissRequest = { goalId = null }, title = { Text("Añadir ahorro") },
            text = { OutlinedTextField(amount, { amount = it }, label = { Text("Monto") }) },
            confirmButton = { TextButton({ vm.addToGoal(goalId!!, amount.toDoubleOrNull() ?: 0.0); goalId = null }) { Text("Guardar") } },
            dismissButton = { TextButton({ goalId = null }) { Text("Cancelar") } })
    }
}

@Composable
fun StatsScreen(vm: FinanceViewModel) {
    val total = vm.income + vm.expenses
    val savingRate = if (vm.income > 0) ((vm.income - vm.expenses) / vm.income * 100).coerceIn(0.0, 100.0) else 0.0
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Estadísticas", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item { SummaryCard("Tasa de ahorro", "%.1f%%".format(savingRate), Icons.Default.PieChart) }
        item { SummaryCard("Ingresos vs gastos", "${money(vm.income)} / ${money(vm.expenses)}", Icons.Default.BarChart) }
        item {
            Text("Distribución", fontWeight = FontWeight.Bold)
            if (total == 0.0) Text("Registra movimientos para ver tus estadísticas.")
            else {
                Text("Ingresos: ${(vm.income / total * 100).toInt()}%")
                LinearProgressIndicator({ (vm.income / total).toFloat().coerceIn(0f,1f) }, Modifier.fillMaxWidth())
                Text("Gastos: ${(vm.expenses / total * 100).toInt()}%")
                LinearProgressIndicator({ (vm.expenses / total).toFloat().coerceIn(0f,1f) }, Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
fun DebtScreen() {
    LazyColumn(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Deudas", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Módulo de préstamos", fontWeight = FontWeight.Bold)
                    Text("La V1 incluye la pantalla base. La siguiente iteración puede añadir saldo, tasa, cuota, abonos al capital y fecha de cancelación.")
                    Button(onClick = {}) { Text("Añadir préstamo") }
                }
            }
        }
    }
}

@Composable
fun MainTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = lightColorScheme(), content = content)
}


data class SalaryResult(
    val monthlyGross: Double,
    val socialSecurity: Double,
    val educational: Double,
    val annualTaxable: Double,
    val annualIsr: Double,
    val monthlyIsr: Double,
    val monthlyNet: Double,
    val biweeklyNet: Double
)

// Estimación para asalariado. Se usa 13 pagos para proyectar el ISR.
// El seguro educativo se calcula sobre los 12 salarios ordinarios;
// el décimo tercero tiene tratamiento especial.
fun calculateSalary(monthlyGross: Double, educationalRate: Double = 0.0125): SalaryResult {
    val ssMonthly = monthlyGross * 0.0975
    val eduMonthly = monthlyGross * educationalRate
    val annualGross = monthlyGross * 13.0
    val annualSs = ssMonthly * 12.0
    val annualEdu = eduMonthly * 12.0
    val taxable = (annualGross - annualSs - annualEdu).coerceAtLeast(0.0)

    val annualIsr = when {
        taxable <= 11000.0 -> 0.0
        taxable <= 50000.0 -> (taxable - 11000.0) * 0.15
        else -> 5850.0 + (taxable - 50000.0) * 0.25
    }
    val monthlyIsr = annualIsr / 12.0
    val monthlyNet = monthlyGross - ssMonthly - eduMonthly - monthlyIsr
    return SalaryResult(
        monthlyGross, ssMonthly, eduMonthly, taxable,
        annualIsr, monthlyIsr, monthlyNet, monthlyNet / 2.0
    )
}

@Composable
fun SalaryScreen() {
    var gross by remember { mutableStateOf("") }
    var period by remember { mutableStateOf("Mensual") }
    var education by remember { mutableStateOf("1.25") }
    val grossMonthly = gross.toDoubleOrNull()?.let {
        if (period == "Quincenal") it * 2.0 else it
    } ?: 0.0
    val result = calculateSalary(grossMonthly, (education.toDoubleOrNull() ?: 1.25) / 100.0)

    LazyColumn(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Calculadora de salario", style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold)
            Text("Panamá · estimación de salario neto")
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(period == "Mensual", { period = "Mensual" }, label = { Text("Mensual") })
                FilterChip(period == "Quincenal", { period = "Quincenal" }, label = { Text("Quincenal") })
            }
        }
        item {
            OutlinedTextField(
                value = gross, onValueChange = { gross = it },
                label = { Text("Ingreso bruto ${period.lowercase()}") },
                prefix = { Text("$ ") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            OutlinedTextField(
                value = education, onValueChange = { education = it },
                label = { Text("Seguro Educativo (%)") },
                supportingText = { Text("La app deja la tasa editable; por defecto usa 1.25%.") },
                modifier = Modifier.fillMaxWidth()
            )
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Desglose mensual", fontWeight = FontWeight.Bold)
                    Text("Bruto: ${money(result.monthlyGross)}")
                    Text("CSS 9.75%: -${money(result.socialSecurity)}")
                    Text("Seguro Educativo: -${money(result.educational)}")
                    Text("ISR estimado: -${money(result.monthlyIsr)}")
                    HorizontalDivider()
                    Text("Neto mensual: ${money(result.monthlyNet)}",
                        style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Neto quincenal aproximado: ${money(result.biweeklyNet)}")
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Proyección anual", fontWeight = FontWeight.Bold)
                    Text("Renta gravable estimada: ${money(result.annualTaxable)}")
                    Text("ISR anual estimado: ${money(result.annualIsr)}")
                    Text("La proyección considera 13 pagos para el ISR.")
                }
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MainTheme { App(viewModel()) }
        }
    }
}
